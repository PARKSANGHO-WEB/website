$(document).ready(function(){
    $(".faq_title").click(function(){
        $(this).siblings('.faq_ans').slideToggle();
        $(this).parents().siblings().children('.faq_ans').slideUp();
    });
});