$(document).ready(function(){
    $(".hover_item").on("click",function(){
        $(this).children('p').toggleClass("color");
        $(this).children('.pack_dep').toggleClass("block");
        $(this).siblings().children('p').removeClass('color');
        $(this).siblings().children('.pack_dep').removeClass('block');
    });
    $(".hover_item").on("mouseenter",function(){
        $(this).children('p').addClass('color');
        $(this).children('.pack_dep').addClass('block');
    });
    $(".hover_item").on("mouseleave",function(){
        $(this).children('p').removeClass('color');
        $(this).children('.pack_dep').removeClass('block');
    });
    
    
    $(".faq_title").click(function(){
        $(this).siblings('.faq_ans').slideToggle();
        $(this).parents().siblings().children('.faq_ans').slideUp();
    });
    
    $(document).ready(function() {
      $('input').click(function() {
        $('input:not(:checked)').parent().removeClass("checked");
        $('input:checked').parent().addClass("checked");
      });
    });
    


    $(document).ready(function(){// Click function for show the Modal

    // Get the modal
    var modal = document.getElementById("myModal");

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal 
    btn.onclick = function() {
      modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }
    });
    
    
    
    
    $(document).ready(function(){
        $('.tab').click(function(){
        var target = $(this).data('process_img-id');
        $('.process_img').css('z-index', '0'); //resets z-index to 0 for all other
        $('.process_img#'+target).css('z-index', '1'); //sets z-index for current target to 1
        $(this).parents().siblings().children().removeClass('tabed');
        $(this).addClass('tabed');
      }); 
    });
    
    
    
    
    $(document).ready(function(){
        $('.tab2').click(function(){
        var target = $(this).data('species-id');
        $('.species').css('display', 'none'); //resets z-index to 0 for all other
        $('.species#'+target).css('display', 'block'); //sets z-index for current target to 1
        $(this).parents().siblings().children().removeClass('tabed2');
        $(this).addClass('tabed2');
      }); 
    });
    
    
});